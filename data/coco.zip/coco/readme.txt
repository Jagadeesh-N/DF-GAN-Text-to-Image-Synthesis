1. Extract ''train2014-text.zip'' and ''val2014-text.zip'' to 'text'

2. Download the coco 2014 Train & Val images and extract them into ''images'':
         http://cocodataset.org/#download

3. [Optional] If you want to use the per-trained models, please download the dictionary, “captions.pickle”.
